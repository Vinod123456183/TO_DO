import express from "express";
import {
  createHabit,
  getHabits,
  getHabit,
  updateHabit,
  deleteHabit,
} from "../controllers/habitController.js";
import { getCalendar } from "../controllers/logController.js";
import authMiddleware from "../middleware/authMiddleware.js";

const router = express.Router();

router.post("/", authMiddleware, createHabit);
router.get("/", authMiddleware, getHabits);
router.get("/:habitId/calendar", authMiddleware, getCalendar);
router.get("/:id", authMiddleware, getHabit);
router.put("/:id", authMiddleware, updateHabit);
router.delete("/:id", authMiddleware, deleteHabit);




export default router;
