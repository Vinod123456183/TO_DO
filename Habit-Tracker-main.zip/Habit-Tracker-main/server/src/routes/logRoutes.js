import express from "express";
import { logHabit, getLogs, getCalendar, getSummary } from "../controllers/logController.js";
import authMiddleware from "../middleware/authMiddleware.js";

const router = express.Router();

router.post("/:habitId/log", authMiddleware, logHabit);
router.get("/:habitId/logs", authMiddleware, getLogs);
router.get("/:habitId/calendar", authMiddleware, getCalendar);
router.get("/:habitId/summary", authMiddleware, getSummary);


export default router;
