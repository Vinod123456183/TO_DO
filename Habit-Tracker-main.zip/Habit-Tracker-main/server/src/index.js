import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import mongoose from "mongoose";
import authRoutes from "./routes/authRoutes.js";
import habitRoutes from "./routes/habitRoutes.js";
import logRoutes from "./routes/logRoutes.js";

dotenv.config();
const app = express();

app.use(cors({
   origin: "http://localhost:5173",
  credentials: true
}));
app.use(express.json());
app.use("/auth", authRoutes);
app.use("/habits", habitRoutes);
app.use("/habits", logRoutes);


// basic route
app.get("/", (req, res) => {
  res.send("Smart Habit Tracker API is running...");
});

// DB connect
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.log("DB Error:", err));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
