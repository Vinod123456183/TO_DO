import HabitLog from "../models/HabitLog.js";
import Habit from "../models/Habit.js";
import Log from "../models/Log.js";
import moment from "moment";


// LOG HABIT FOR TODAY
export const logHabit = async (req, res) => {
  try {
    const { habitId } = req.params;

    const today = new Date().toISOString().slice(0, 10);

    // Check if already logged for today
    const existingLog = await HabitLog.findOne({ habitId, date: today });
    if (existingLog) {
      return res.status(400).json({ msg: "Already logged for today" });
    }

    // Save log
    const log = await HabitLog.create({
      habitId,
      date: today,
      done: true,
    });

    // Update streak
    const yesterday = new Date(Date.now() - 86400000)
      .toISOString()
      .slice(0, 10);

    const yesterdayLog = await HabitLog.findOne({
      habitId,
      date: yesterday,
    });

    if (yesterdayLog) {
      await Habit.findByIdAndUpdate(habitId, { $inc: { streak: 1 } });
    } else {
      await Habit.findByIdAndUpdate(habitId, { streak: 1 });
    }

    res.json({ msg: "Logged successfully", log });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET ALL LOGS
export const getLogs = async (req, res) => {
  try {
    const { habitId } = req.params;
    const logs = await HabitLog.find({ habitId }).sort({ date: 1 });
    res.json(logs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};


export const getCalendar = async (req, res) => {
  try {
    const { habitId } = req.params;

    // get logs from HabitLog (Correct model)
    const logs = await HabitLog.find({ habitId });

    const days = [];
    const today = moment();

    for (let i = 0; i < 30; i++) {
      const date = today.clone().subtract(i, "days").format("YYYY-MM-DD");

      const done = logs.some((log) => log.date === date);

      days.push({
        date,
        done,
      });
    }

    res.json(days.reverse());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};


// WEEKLY SUMMARY
export const getSummary = async (req, res) => {
  try {
    const { habitId } = req.params;

    const today = new Date();
    const lastWeek = new Date(Date.now() - 7 * 86400000);

    const logs = await HabitLog.find({
      habitId,
      date: {
        $gte: lastWeek.toISOString().slice(0, 10),
      },
    }).sort({ date: 1 });

    const completedDays = logs.length;

    res.json({
      completedDays,
      totalDays: 7,
      percentage: Number(((completedDays / 7) * 100).toFixed(2)),
      logs,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
