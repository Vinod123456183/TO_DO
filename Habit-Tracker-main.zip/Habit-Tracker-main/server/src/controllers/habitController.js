import Habit from "../models/Habit.js";

// CREATE
export const createHabit = async (req, res) => {
  try {
    const { title, description, difficulty } = req.body;

    const habit = await Habit.create({
      userId: req.user.id,
      title,
      description,
      difficulty,
    });

    res.status(201).json(habit);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET ALL USER HABITS
export const getHabits = async (req, res) => {
  try {
    const habits = await Habit.find({ userId: req.user.id });
    res.json(habits);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET ONE HABIT
export const getHabit = async (req, res) => {
  try {
    const habit = await Habit.findById(req.params.id);
    res.json(habit);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// UPDATE HABIT
export const updateHabit = async (req, res) => {
  try {
    const habit = await Habit.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    res.json(habit);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// DELETE HABIT
export const deleteHabit = async (req, res) => {
  try {
    await Habit.findByIdAndDelete(req.params.id);
    res.json({ msg: "Habit deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
