from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from datetime import datetime, timedelta

app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],  # React dev server
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class HabitLog(BaseModel):
    date: str
    completed: bool

class AnalysisRequest(BaseModel):
    logs: List[HabitLog]

class PredictionRequest(BaseModel):
    logs: List[HabitLog]
    difficulty: str

@app.get("/")
def read_root():
    return {"message": "AI Brain is active 🧠"}

@app.post("/analyze")
def analyze_consistency(req: AnalysisRequest):
    if not req.logs:
        return {"analysis": "Not enough data to analyze."}

    df = pd.DataFrame([l.dict() for l in req.logs])
    df['date'] = pd.to_datetime(df['date'])
    df['day_name'] = df['date'].dt.day_name()
    df['is_weekend'] = df['day_name'].isin(['Saturday', 'Sunday'])

    weekend_completion = df[df['is_weekend']]['completed'].mean() if not df[df['is_weekend']].empty else 0
    weekday_completion = df[~df['is_weekend']]['completed'].mean() if not df[~df['is_weekend']].empty else 0

    analysis = "Your consistency is balanced."
    
    if weekend_completion < weekday_completion - 0.2:
        analysis = "Your energy tends to drop on weekends."
    elif weekday_completion < weekend_completion - 0.2:
        analysis = "You are more consistent on weekends."
    
    return {"analysis": analysis}

@app.post("/predict")
def predict_streak_break(req: PredictionRequest):
    if len(req.logs) < 5:
        return {"probability": 50, "message": "Need more data for prediction."}

    df = pd.DataFrame([l.dict() for l in req.logs])
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date')
    
    # Simple feature: Days since start
    df['days_since'] = (df['date'] - df['date'].min()).dt.days
    
    # Target: Completed (1) or Not (0)
    # We want to predict if the NEXT day will be completed.
    # But for streak break, we want prob of NOT completing.
    
    X = df[['days_since']].values.reshape(-1, 1)
    y = df['completed'].astype(int).values

    model = LinearRegression()
    model.fit(X, y)

    next_day = df['days_since'].max() + 1
    prob_completion = model.predict([[next_day]])[0]
    
    # Clamp probability
    prob_completion = max(0, min(1, prob_completion))
    
    prob_break = (1 - prob_completion) * 100
    
    # Adjust based on difficulty
    if req.difficulty == "Hard":
        prob_break += 10
    elif req.difficulty == "Easy":
        prob_break -= 10
        
    prob_break = max(0, min(100, prob_break))

    return {
        "probability": round(prob_break, 1),
        "message": f"{round(prob_break)}% chance of breaking streak tomorrow."
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
