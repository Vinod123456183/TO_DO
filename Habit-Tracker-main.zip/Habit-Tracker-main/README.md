# Habit Tracker

A full-stack habit tracking application with AI-powered insights, built with React, Node.js, and FastAPI.

## Features

- **Habit Management**: Create, track, and delete habits with difficulty levels
- **Daily Dashboard**: Track daily progress with visual completion indicators
- **Streak Tracking**: Monitor current and best streaks for each habit
- **Calendar View**: Visualize habit completion history in a monthly calendar
- **AI Insights**: Get personalized consistency analysis and streak predictions
- **Dark/Light Mode**: Minimalistic black & white paper theme
- **User Authentication**: Secure login and registration

## Tech Stack

### Frontend
- React 19
- React Router 7
- Vite
- Axios
- date-fns

### Backend
- Node.js
- Express 5
- MongoDB (Mongoose)
- JWT Authentication
- bcryptjs

### AI Service
- FastAPI
- scikit-learn
- pandas
- numpy

## Getting Started

### Prerequisites
- Node.js (v18+)
- Python (v3.10+)
- MongoDB

### Installation

1. **Clone the repository**
```bash
git clone <repository-url>
cd habit-tracker
```

2. **Install server dependencies**
```bash
cd server
npm install
```

3. **Install client dependencies**
```bash
cd ../client
npm install
```

4. **Install AI service dependencies**
```bash
cd ..
python -m pip install -r ai/requirements.txt
```

5. **Configure environment variables**

Create `server/.env`:
```env
MONGO_URI=mongodb://localhost:27017/habit-tracker
JWT_SECRET=your-secret-key-here
PORT=5000
```

### Running the Application

You need to run three services:

1. **MongoDB** (ensure it's running on localhost:27017)

2. **Backend Server**
```bash
cd server
npm run dev
```

3. **Frontend**
```bash
cd client
npm run dev
```

4. **AI Service**
```bash
python ai/main.py
```

The application will be available at:
- Frontend: http://localhost:5173
- Backend API: http://localhost:5000
- AI Service: http://localhost:8000

## Project Structure

```
habit-tracker/
├── client/              # React frontend
│   ├── src/
│   │   ├── api/        # API configuration
│   │   ├── components/ # Reusable components
│   │   ├── context/    # React contexts (Auth, Theme)
│   │   ├── pages/      # Page components
│   │   └── index.css   # Global styles
│   └── package.json
├── server/              # Express backend
│   ├── src/
│   │   ├── controllers/
│   │   ├── middleware/
│   │   ├── models/
│   │   └── routes/
│   └── package.json
└── ai/                  # FastAPI AI service
    ├── main.py
    └── requirements.txt
```

## AI Features

The AI service provides:
- **Consistency Analysis**: Identifies patterns like "Your energy drops on weekends"
- **Streak Prediction**: Calculates probability of breaking your streak

## Design

The application features a minimalistic black & white "paper" theme with:
- Clean, monospace typography
- High contrast for readability
- Smooth theme transitions
- Hard shadows for a tactile feel

## License

MIT

## Author

Built by [@Mohiit007](https://github.com/Mohiit007)
