import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { useTheme } from "../context/ThemeContext";

export default function Sidebar() {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const { theme, toggleTheme } = useTheme();

  // close mobile sidebar on route change
  useEffect(() => {
    setOpen(false);
  }, [location]);

  return (
    <>
      {/* Mobile Toggle */}
      <button
        className="sidebar-toggle btn-outline"
        aria-label="Open menu"
        onClick={() => setOpen(true)}
      >
        MENU
      </button>

      {/* Overlay */}
      <div
        className={`sidebar-overlay ${open ? "show" : ""}`}
        onClick={() => setOpen(false)}
      />

      <aside className={`sidebar ${open ? "open" : ""}`}>
        <div className="sidebar-header">
          <div className="logo-text">HABIT TRACKER</div>
          <button
            className="close-btn"
            onClick={() => setOpen(false)}
            aria-label="Close menu"
          >
            X
          </button>
        </div>

        <nav className="sidebar-nav">
          <Link to="/dashboard" className={location.pathname === "/dashboard" ? "active" : ""}>
            DASHBOARD
          </Link>
          <Link to="/add-habit" className={location.pathname === "/add-habit" ? "active" : ""}>
            ADD HABIT
          </Link>
          <Link to="/settings" className={location.pathname === "/settings" ? "active" : ""}>
            SETTINGS
          </Link>
        </nav>

        <div className="sidebar-footer">
          <button onClick={toggleTheme} className="theme-toggle btn-outline">
            {theme === "light" ? "DARK MODE" : "LIGHT MODE"}
          </button>
        </div>
      </aside>
    </>
  );
}
