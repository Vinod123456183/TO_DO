import { Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import Register from "./pages/Register";
import ProtectedRoute from "./components/ProtectedRoute";
import Dashboard from "./pages/Dashboard";
import AddHabit from "./pages/AddHabit";
import HabitDetail from "./pages/HabitDetail";
import CalendarPage from "./pages/CalendarPage";
import Layout from "./components/Layout";
import Settings from "./pages/Settings";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/register" element={<Register />} />

      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <Layout>
              <Dashboard />
            </Layout>
          </ProtectedRoute>
        }
      />

      <Route
        path="/add-habit"
        element={
          <ProtectedRoute>
            <Layout>
              <AddHabit />
            </Layout>
          </ProtectedRoute>
        }
      />

      <Route
        path="/habit/:id"
        element={
          <ProtectedRoute>
            <Layout>
              <HabitDetail />
            </Layout>
          </ProtectedRoute>
        }
      />

      <Route
        path="/habit/:id/calendar"
        element={
          <ProtectedRoute>
            <Layout>
              <CalendarPage />
            </Layout>
          </ProtectedRoute>
        }
      />

      <Route
        path="/settings"
        element={
          <ProtectedRoute>
            <Layout>
              <Settings />
            </Layout>
          </ProtectedRoute>
        }
      />
    </Routes>
  );
}
