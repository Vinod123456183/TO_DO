import { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import API from "../api/axios";
import { format, parseISO, isToday, isYesterday } from "date-fns";

export default function HabitDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [habit, setHabit] = useState(null);
  const [logs, setLogs] = useState([]);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [logLoading, setLogLoading] = useState(false);

  const fetchHabit = async () => {
    try {
      const res = await API.get(`/habits/${id}`);
      setHabit(res.data);
    } catch (err) {
      console.error("Error fetching habit:", err);
      setMessage("Failed to load habit details");
    }
  };

  const fetchLogs = async () => {
    try {
      const res = await API.get(`/habits/${id}/logs`);
      const sorted = res.data.sort((a, b) => new Date(b.date) - new Date(a.date));
      setLogs(sorted);
    } catch (err) {
      console.error("Error fetching logs:", err);
      setMessage("Failed to load logs");
    }
  };

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      await Promise.all([fetchHabit(), fetchLogs()]);
      setLoading(false);
    };
    load();
  }, [id]);

  const formatDate = (dateString) => {
    const date = parseISO(dateString);
    if (isToday(date)) return "TODAY";
    if (isYesterday(date)) return "YESTERDAY";
    return format(date, "EEE, MMM d").toUpperCase();
  };

  const logToday = async () => {
    try {
      setLogLoading(true);
      const today = new Date().toISOString().split("T")[0];
      const todayLog = logs.find(log => log.date === today);

      if (todayLog) {
        await API.delete(`/habits/${id}/log/${todayLog._id}`);
        setMessage("LOG REMOVED");
      } else {
        await API.post(`/habits/${id}/log`);
        setMessage("LOGGED SUCCESSFULLY");
      }
      await Promise.all([fetchHabit(), fetchLogs()]);
    } catch (err) {
      console.error(err);
      setMessage("ERROR UPDATING LOG");
    } finally {
      setLogLoading(false);
      setTimeout(() => setMessage(""), 3000);
    }
  };

  const handleDelete = async () => {
    if (window.confirm("ARE YOU SURE YOU WANT TO DELETE THIS HABIT? THIS ACTION CANNOT BE UNDONE.")) {
      try {
        await API.delete(`/habits/${id}`);
        navigate("/dashboard");
      } catch (err) {
        console.error("Error deleting habit:", err);
        setMessage("FAILED TO DELETE HABIT");
      }
    }
  };

  if (loading) return <div className="container text-center mt-4">LOADING...</div>;

  return (
    <div className="container">
      <Link to="/dashboard" className="btn btn-outline mb-4">BACK TO DASHBOARD</Link>

      <div className="card mb-4">
        <div className="flex justify-between items-start">
          <div>
            <h1 style={{ marginBottom: "0.5rem" }}>{habit.title}</h1>
            {habit.description && <p className="text-muted">{habit.description}</p>}
          </div>
          <span className="badge">{habit.difficulty}</span>
        </div>

        <div className="grid grid-3 mt-4">
          <div className="card" style={{ background: "transparent", border: "none", padding: "0" }}>
            <div className="text-muted text-center">CURRENT STREAK</div>
            <div className="text-center" style={{ fontSize: "1.5rem", fontWeight: 700 }}>{habit.streak}</div>
          </div>
          <div className="card" style={{ background: "transparent", border: "none", padding: "0" }}>
            <div className="text-muted text-center">TOTAL LOGS</div>
            <div className="text-center" style={{ fontSize: "1.5rem", fontWeight: 700 }}>{logs.length}</div>
          </div>
          <div className="card" style={{ background: "transparent", border: "none", padding: "0" }}>
            <div className="text-muted text-center">LAST LOGGED</div>
            <div className="text-center" style={{ fontSize: "1.25rem", fontWeight: 700 }}>{logs[0] ? formatDate(logs[0].date) : "NEVER"}</div>
          </div>
        </div>
      </div>

      <div className="card mb-4">
        <button
          onClick={logToday}
          disabled={logLoading}
          className={`btn ${logs.some(l => isToday(parseISO(l.date))) ? "btn-outline" : "btn-primary"}`}
          style={{ width: "100%" }}
        >
          {logs.some(l => isToday(parseISO(l.date))) ? "UNDO TODAY'S LOG" : "LOG TODAY"}
        </button>

        {message && <div className="text-center mt-4 text-muted">{message}</div>}

        <div className="text-center mt-4">
          <Link to={`/habit/${id}/calendar`} className="btn btn-outline">VIEW CALENDAR</Link>
        </div>

        <div className="text-center mt-4" style={{ borderTop: "1px solid var(--border)", paddingTop: "1rem" }}>
          <button onClick={handleDelete} className="btn btn-danger">DELETE HABIT</button>
        </div>
      </div>

      <div className="card">
        <h2>ACTIVITY LOGS</h2>
        {logs.length === 0 ? (
          <p className="text-muted">NO LOGS RECORDED YET.</p>
        ) : (
          <div className="flex flex-col gap-2">
            {logs.map((log) => (
              <div key={log._id} className="flex justify-between items-center p-2" style={{ borderBottom: "1px solid var(--border)" }}>
                <div>{formatDate(log.date)}</div>
                <div className="badge">COMPLETED</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
