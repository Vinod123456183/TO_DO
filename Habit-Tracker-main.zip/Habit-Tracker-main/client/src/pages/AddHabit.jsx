import { useState } from "react";
import API from "../api/axios";
import { Link } from "react-router-dom";

export default function AddHabit() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [difficulty, setDifficulty] = useState("easy");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await API.post("/habits", { title, description, difficulty });
      setMessage("Habit created successfully!");
      setTitle("");
      setDescription("");
      setDifficulty("easy");
    } catch (err) {
      setMessage(err.response?.data?.msg || "Error creating habit");
    }
    setTimeout(() => setMessage(""), 3000);
  };

  return (
    <div className="container">
      <Link to="/dashboard" className="btn btn-outline mb-4">← Back to Dashboard</Link>

      <div className="card" style={{ maxWidth: 600, margin: "0 auto" }}>
        <h1 className="text-center mb-4">Add New Habit</h1>

        {message && (
          <div className="text-center mb-4" style={{ color: message.includes("Error") ? "var(--danger)" : "var(--success)" }}>
            {message}
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className="form-label">Habit Title</label>
            <input
              className="input"
              placeholder="e.g., Read 30 minutes"
              value={title}
              onChange={e => setTitle(e.target.value)}
              required
            />
          </div>

          <div>
            <label className="form-label">Description (Optional)</label>
            <input
              className="input"
              placeholder="Why do you want to build this habit?"
              value={description}
              onChange={e => setDescription(e.target.value)}
            />
          </div>

          <div>
            <label className="form-label">Difficulty</label>
            <select
              className="input"
              value={difficulty}
              onChange={e => setDifficulty(e.target.value)}
            >
              <option value="easy">Easy</option>
              <option value="medium">Medium</option>
              <option value="hard">Hard</option>
            </select>
          </div>

          <button className="btn btn-primary mt-4" type="submit">Create Habit</button>
        </form>
      </div>
    </div>
  );
}
