import { useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

// Subtle small logo (same as Dashboard + HabitDetail)
const logoUrl = "/mnt/data/7498a28a-1158-4c23-b68a-71873b216896.png";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const res = await axios.post("http://localhost:5000/auth/login", {
        email,
        password,
      });

      localStorage.setItem("token", res.data.token);
      window.location.href = "/dashboard";
    } catch (err) {
      setError(err.response?.data?.msg || "Login failed");
    }
  };

  return (
    <div className="auth-container">
      <form onSubmit={handleLogin} className="auth-form">
        <div className="auth-header">
          <img src={logoUrl} alt="logo" className="auth-logo" />
          <h2>Welcome Back</h2>
          <p className="text-muted">Sign in to continue tracking your habits</p>
        </div>

        {error && (
          <div style={{ color: "var(--danger)", marginBottom: "1rem", textAlign: "center" }}>
            {error}
          </div>
        )}

        <div className="form-group">
          <input
            type="email"
            placeholder="Email address"
            className="input"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <input
            type="password"
            placeholder="Password"
            className="input"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <button type="submit" className="btn btn-primary" style={{ width: "100%" }}>
          Sign In
        </button>

        <p className="text-center mt-4 text-muted" style={{ fontSize: "0.9rem" }}>
          Don’t have an account?{" "}
          <Link to="/register" style={{ fontWeight: 600 }}>
            Register here
          </Link>
        </p>
      </form>
    </div>
  );
}
