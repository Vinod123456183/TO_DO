import { useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

// Reuse the subtle logo
const logoUrl = "/mnt/data/7498a28a-1158-4c23-b68a-71873b216896.png";

export default function Register() {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleRegister = async (e) => {
    e.preventDefault();

    try {
      await axios.post("http://localhost:5000/auth/register", {
        username,
        email,
        password,
      });

      window.location.href = "/";
    } catch (err) {
      setError(err.response?.data?.msg || "Registration failed");
    }
  };

  return (
    <div className="auth-container">
      <form onSubmit={handleRegister} className="auth-form">
        <div className="auth-header">
          <img src={logoUrl} alt="logo" className="auth-logo" />
          <h2>Create Account</h2>
          <p className="text-muted">Start your journey to better habits</p>
        </div>

        {error && (
          <div style={{ color: "var(--danger)", marginBottom: "1rem", textAlign: "center" }}>
            {error}
          </div>
        )}

        <div className="form-group">
          <input
            type="text"
            placeholder="Username"
            className="input"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <input
            type="email"
            placeholder="Email address"
            className="input"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <input
            type="password"
            placeholder="Password"
            className="input"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <button type="submit" className="btn btn-primary" style={{ width: "100%" }}>
          Create Account
        </button>

        <p className="text-center mt-4 text-muted" style={{ fontSize: "0.9rem" }}>
          Already have an account?{" "}
          <Link to="/" style={{ fontWeight: 600 }}>
            Sign in
          </Link>
        </p>
      </form>
    </div>
  );
}
