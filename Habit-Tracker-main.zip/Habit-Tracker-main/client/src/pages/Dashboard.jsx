import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import API from "../api/axios";
import axios from "axios";
import { Link } from "react-router-dom";
import { format, addDays, isToday, isSameDay, parseISO } from "date-fns";

export default function Dashboard() {
  const { logout } = useAuth();
  const [habits, setHabits] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [completions, setCompletions] = useState({});
  const [saving, setSaving] = useState(false);
  const [aiInsights, setAiInsights] = useState({});

  async function fetchHabits() {
    setLoading(true);
    try {
      const res = await API.get("/habits");
      const list = res.data || [];
      setHabits(list);

      const map = {};
      await Promise.all(
        list.map(async (h) => {
          try {
            const logsRes = await API.get(`/habits/${h._id}/logs`);
            const exists = logsRes.data.some((l) =>
              isSameDay(parseISO(l.date), selectedDate)
            );
            map[h._id] = exists;
          } catch {
            map[h._id] = false;
          }
        })
      );
      setCompletions(map);
    } catch (err) {
      console.error(err);
      setHabits([]);
      setCompletions({});
    } finally {
      setLoading(false);
    }
  }

  async function fetchAIInsights() {
    try {
      const insights = {};
      await Promise.all(
        habits.map(async (h) => {
          try {
            const logsRes = await API.get(`/habits/${h._id}/logs`);
            const logs = logsRes.data.slice(-14).map(l => ({
              date: l.date.substring(0, 10),
              completed: true
            }));

            if (logs.length > 0) {
              const analysisRes = await axios.post("http://localhost:8000/analyze", { logs });
              const predictionRes = await axios.post("http://localhost:8000/predict", {
                logs,
                difficulty: h.difficulty
              });

              insights[h._id] = {
                analysis: analysisRes.data.analysis,
                prediction: predictionRes.data.message
              };
            }
          } catch (err) {
            console.error(`AI insights error for habit ${h._id}:`, err);
          }
        })
      );
      setAiInsights(insights);
    } catch (err) {
      console.error("AI insights fetch error:", err);
    }
  }

  useEffect(() => {
    fetchHabits();
    // eslint-disable-next-line
  }, [selectedDate]);

  useEffect(() => {
    if (habits.length > 0) {
      fetchAIInsights();
    }
    // eslint-disable-next-line
  }, [habits]);

  const toggleHabitCompletion = async (habitId) => {
    const newState = !completions[habitId];
    setCompletions((p) => ({ ...p, [habitId]: newState }));

    setSaving(true);
    try {
      if (newState) {
        await API.post(`/habits/${habitId}/log`, {
          date: format(selectedDate, "yyyy-MM-dd"),
          completed: true,
        });
      } else {
        const logs = await API.get(`/habits/${habitId}/logs`);
        const toDelete = logs.data.find((l) =>
          isSameDay(parseISO(l.date), selectedDate)
        );
        if (toDelete) await API.delete(`/habits/${habitId}/log/${toDelete._id}`);
      }
      await fetchHabits();
    } catch (err) {
      console.error(err);
      setCompletions((p) => ({ ...p, [habitId]: !newState }));
    } finally {
      setSaving(false);
    }
  };

  const completedCount = Object.values(completions).filter(Boolean).length;
  const totalHabits = habits.length;
  const completionPercentage = totalHabits > 0 ? Math.round((completedCount / totalHabits) * 100) : 0;
  const handleDateChange = (days) => setSelectedDate((d) => addDays(d, days));

  return (
    <div>
      <header className="flex justify-between items-center mb-4" style={{ borderBottom: "1px solid var(--border)", paddingBottom: "1rem" }}>
        <div>
          <h1>DAILY DASHBOARD</h1>
          <div className="text-muted">
            {format(selectedDate, "EEEE, MMM d, yyyy").toUpperCase()}
          </div>
        </div>

        <div className="flex gap-2 items-center">
          <button className="btn btn-outline" onClick={() => handleDateChange(-1)}>PREV</button>
          <button className="btn btn-outline" onClick={() => handleDateChange(1)} disabled={isToday(selectedDate)}>NEXT</button>
          <Link to="/add-habit" className="btn btn-primary">ADD</Link>
          <button className="btn btn-danger" onClick={logout}>LOGOUT</button>
        </div>
      </header>

      <div className="card mb-4">
        <div className="flex justify-between items-center">
          <div className="text-muted">{completedCount} / {totalHabits} COMPLETED</div>
          <div style={{ fontWeight: 700 }}>{completionPercentage}%</div>
        </div>

        <div className="progress-container">
          <div className="progress-bar" style={{ width: `${completionPercentage}%` }} />
        </div>
      </div>

      <div className="grid grid-3">
        {loading ? (
          <div className="card">LOADING...</div>
        ) : habits.length === 0 ? (
          <div className="card text-center">
            <p>NO HABITS YET.</p>
            <Link to="/add-habit" className="btn btn-primary">CREATE FIRST HABIT</Link>
          </div>
        ) : (
          habits.map((h) => (
            <article key={h._id} className="card habit-card flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 style={{ fontSize: "1.1rem", marginBottom: "0.25rem" }}>{h.title}</h3>
                    {h.description && <div className="text-muted" style={{ fontSize: "0.85rem" }}>{h.description}</div>}
                  </div>
                  <span className="badge">{h.difficulty}</span>
                </div>

                <div className="text-muted" style={{ fontSize: "0.85rem", marginBottom: "1rem" }}>
                  STREAK: <strong>{h.streak}</strong> • BEST: {h.bestStreak}
                </div>

                {aiInsights[h._id] && (
                  <div style={{
                    borderTop: "1px solid var(--border)",
                    paddingTop: "0.75rem",
                    marginTop: "0.75rem",
                    fontSize: "0.8rem"
                  }}>
                    <div className="text-muted" style={{ marginBottom: "0.25rem" }}>AI INSIGHTS:</div>
                    <div style={{ fontStyle: "italic" }}>{aiInsights[h._id].analysis}</div>
                    <div style={{ fontStyle: "italic", marginTop: "0.25rem" }}>{aiInsights[h._id].prediction}</div>
                  </div>
                )}
              </div>

              <div className="flex gap-2 mt-4">
                <button
                  className={`btn ${completions[h._id] ? "btn-primary" : "btn-outline"}`}
                  style={{ flex: 1 }}
                  onClick={() => toggleHabitCompletion(h._id)}
                  disabled={saving}
                >
                  {completions[h._id] ? "DONE" : "MARK"}
                </button>

                <Link to={`/habit/${h._id}`} className="btn btn-outline">
                  VIEW
                </Link>
              </div>
            </article>
          ))
        )}
      </div>
    </div>
  );
}
