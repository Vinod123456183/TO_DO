import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import API from "../api/axios";
import {
  format,
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  addDays,
  isToday
} from "date-fns";

export default function CalendarPage() {
  const { id } = useParams();
  const [logs, setLogs] = useState([]);
  const [monthMatrix, setMonthMatrix] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    API.get(`/habits/${id}/logs`)
      .then((res) => {
        setLogs(res.data);
        buildCalendar(res.data);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [id]);

  function buildCalendar(logs) {
    const today = new Date();
    const monthStart = startOfMonth(today);
    const monthEnd = endOfMonth(today);
    const start = startOfWeek(monthStart, { weekStartsOn: 1 });
    const end = endOfWeek(monthEnd, { weekStartsOn: 1 });

    let day = start;
    const matrix = [];

    while (day <= end) {
      const week = [];
      for (let i = 0; i < 7; i++) {
        const dateStr = format(day, "yyyy-MM-dd");
        const done = logs.some((l) => l.date.substring(0, 10) === dateStr);

        week.push({
          date: dateStr,
          dayNum: format(day, "d"),
          done,
          today: isToday(day)
        });

        day = addDays(day, 1);
      }
      matrix.push(week);
    }

    setMonthMatrix(matrix);
  }

  if (loading) return <div className="container text-center mt-4">LOADING CALENDAR...</div>;

  return (
    <div className="container">
      <Link to={`/habit/${id}`} className="btn btn-outline mb-4">BACK TO HABIT</Link>

      <div className="card">
        <h1 className="text-center mb-4">HABIT CALENDAR</h1>

        <div className="calendar-weekdays grid grid-7 text-center text-muted" style={{ marginBottom: "0.5rem" }}>
          {["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"].map((d) => (
            <div key={d} className="weekday-label">{d}</div>
          ))}
        </div>

        <div className="calendar-grid grid grid-7" style={{ gap: "0.5rem" }}>
          {monthMatrix.flat().map((d) => (
            <div
              key={d.date}
              className={`calendar-day ${d.done ? "done" : ""} ${d.today ? "today" : ""}`}
              title={d.date}
            >
              {d.dayNum}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
