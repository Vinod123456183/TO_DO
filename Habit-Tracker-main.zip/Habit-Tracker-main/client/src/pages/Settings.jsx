import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useTheme } from "../context/ThemeContext";
import API from "../api/axios";

export default function Settings() {
    const { logout } = useAuth();
    const { theme, toggleTheme } = useTheme();
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        API.get("/auth/me")
            .then((res) => setUser(res.data))
            .catch((err) => console.error("Failed to fetch user", err))
            .finally(() => setLoading(false));
    }, []);

    if (loading) return <div className="container text-center mt-4">LOADING...</div>;

    return (
        <div className="container">
            <Link to="/dashboard" className="btn btn-outline mb-4">BACK TO DASHBOARD</Link>

            <h1 className="mb-4">SETTINGS</h1>

            <div className="grid grid-3">
                {/* PROFILE CARD */}
                <div className="card">
                    <h2 style={{ fontSize: "1.2rem", borderBottom: "1px solid var(--border)", paddingBottom: "0.5rem" }}>PROFILE</h2>
                    <div className="mt-4">
                        <div className="form-group">
                            <label className="form-label text-muted">USERNAME</label>
                            <div style={{ fontWeight: 600 }}>{user?.username || "N/A"}</div>
                        </div>
                        <div className="form-group">
                            <label className="form-label text-muted">EMAIL</label>
                            <div style={{ fontWeight: 600 }}>{user?.email || "N/A"}</div>
                        </div>
                    </div>
                </div>

                {/* APPEARANCE CARD */}
                <div className="card">
                    <h2 style={{ fontSize: "1.2rem", borderBottom: "1px solid var(--border)", paddingBottom: "0.5rem" }}>APPEARANCE</h2>
                    <div className="mt-4">
                        <p className="text-muted mb-4">Current Theme: <strong>{theme.toUpperCase()}</strong></p>
                        <button onClick={toggleTheme} className="btn btn-outline" style={{ width: "100%" }}>
                            SWITCH TO {theme === "light" ? "DARK" : "LIGHT"} MODE
                        </button>
                    </div>
                </div>

                {/* ACCOUNT CARD */}
                <div className="card">
                    <h2 style={{ fontSize: "1.2rem", borderBottom: "1px solid var(--border)", paddingBottom: "0.5rem" }}>ACCOUNT</h2>
                    <div className="mt-4">
                        <p className="text-muted mb-4">Manage your account access.</p>
                        <button onClick={logout} className="btn btn-danger" style={{ width: "100%" }}>
                            LOGOUT
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
