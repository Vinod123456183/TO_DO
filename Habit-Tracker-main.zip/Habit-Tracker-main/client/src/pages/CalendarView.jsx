import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import API from "../api/axios";
import {
  format,
  startOfMonth,
  endOfMonth,
  startOfWeek,
  addDays,
  isToday
} from "date-fns";

export default function CalendarView() {
  const { id } = useParams();
  const [logs, setLogs] = useState([]);
  const [matrix, setMatrix] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    API.get(`/habits/${id}/calendar`)
      .then((res) => {
        setLogs(res.data);
        buildCalendar(res.data);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [id]);

  function buildCalendar(logData) {
    const today = new Date();
    const start = startOfWeek(startOfMonth(today), { weekStartsOn: 1 });
    const end = startOfWeek(endOfMonth(today), { weekStartsOn: 1 });

    const temp = [];
    let day = start;

    while (day <= end) {
      const week = [];
      for (let i = 0; i < 7; i++) {
        const dateStr = format(day, "yyyy-MM-dd");
        const found = logData.some((l) => l.day === dateStr);

        week.push({
          date: dateStr,
          num: format(day, "d"),
          done: found,
          today: isToday(day),
        });

        day = addDays(day, 1);
      }
      temp.push(week);
    }

    setMatrix(temp);
  }

  if (loading)
    return <div className="loading">Loading calendar...</div>;

  return (
    <div className="container" style={{ paddingTop: "1rem" }}>
      <Link to={`/habit/${id}`} style={{ color: "var(--primary)" }}>
        ← Back
      </Link>

      <h1 style={{ marginTop: "1rem" }}>Calendar</h1>

      {/* Day Names */}
      <div
        className="grid-7"
        style={{ marginTop: "1rem", fontWeight: 600, textAlign: "center" }}
      >
        {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d) => (
          <div key={d}>{d}</div>
        ))}
      </div>

      {/* Calendar Matrix */}
      {matrix.map((week, i) => (
        <div className="grid-7" key={i} style={{ marginTop: ".5rem" }}>
          {week.map((d, j) => (
            <div
              key={j}
              className="card"
              style={{
                textAlign: "center",
                padding: "0.75rem",

                /* If completed */
                background: d.done ? "var(--success)" :

                  /* If today & not completed */
                  d.today ? "var(--primary)" :

                    /* Normal */
                    "var(--bg-card)",

                color: d.done || d.today ? "#fff" : "var(--text-primary)",

                border: d.today
                  ? "2px solid var(--primary-hover)"
                  : "1px solid var(--border-color)"
              }}

            >
              {d.num}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}
