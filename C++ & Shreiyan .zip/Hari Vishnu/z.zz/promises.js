// Example function that returns a Promise
function fetchData() {
    return new Promise((resolve, reject) => {
        // Simulating asynchronous data fetching
        setTimeout(() => {
            const data = "Some fetched data";
            // Simulate success
            resolve(data);
            // Simulate failure
            // reject(new Error("Failed to fetch data"));
        }, 2000);
    });
}

console.log("Fetching data...");
fetchData()
    .then(data => {
        console.log("Data fetched successfully:", data);
    })
    .catch(error => {
        console.error("Error fetching data:", error);
    });
