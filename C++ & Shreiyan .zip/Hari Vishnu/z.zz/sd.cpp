#include <bits/stdc++.h>
using namespace std;


int main(){
    vector<int>a = {1,2,3,4,5,6,7,8,9,10,9};
    int x = -1 , y = -1;
    for(int i = 0 ; i<a.size(); i++) 
    {
        if(a[i] == 6)
            x = i;
    }
    for(int i = a.size()-1; i>=0; i--) 
    {
        if(a[i] == 9)
            y = i;
    }

    cout<<y<<" - "<<x;



    // cout<<y-x;
    
}