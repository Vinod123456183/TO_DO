// // // #include <bits/stdc++.h>
// // // #include<algorithm>
// // // using namespace std;
// // // int main(){
// // //         string s[4];
// // //         for (int i = 0; i < 4; i++) {
// // //             cout << "Enter string " << i + 1 << ": ";
// // //             cin >> s[i];
// // //         }
// // //     sort(s,s+1);
    
// // //         for (int i = 0; i < 4; i++) {
// // //         // cout << "Enter string " << i + 1 << ": ";
// // //         cout << s[i] <<" ";
// // //     }SKFU08
// // //     return 0;
// // // }

// // #include <iostream>
// // #include <string>

// // void bubbleSort(std::string arr[], int size) {
// //     for (int i = 0; i < size - 1; ++i) {
// //         for (int j = 0; j < size - i - 1; ++j) {
// //             if (arr[j] > arr[j + 1]) {
// //                 // Swap arr[j] and arr[j + 1]
// //                 std::string temp = arr[j];
// //                 arr[j] = arr[j + 1];
// //                 arr[j + 1] = temp;
// //             }
// //         }
// //     }
// // }

// // int main() {
// //     const int size = 10;
// //     std::string strings[size];

// //     // Get ten strings from the user
// //     for (int i = 0; i < size; ++i) {
// //         std::cout << "Enter string " << i + 1 << ": ";
// //         std::cin >> strings[i];
// //     }

// //     // Sort the strings using bubble sort
// //     bubbleSort(strings, size);

// //     // Display the sorted strings
// //     std::cout << "Sorted strings in dictionary order:" << std::endl;
// //     for (const std::string& str : strings) {
// //         std::cout << str << std::endl;
// //     }

// //     return 0;
// // }


// // #include <bits/stdc++.h>
// //  using namespace std;
// // int main(){
// //     long long  ans = 1;
// //     for(int i= 0; i<51;i++){
// //         ans += 2;
// //     }
// //     cout<<ans;
// // }

// #include <bits/stdc++.h>
//  using namespace std;
// int main(){
//     for(int i= 0 ;i <100; i++) {
//         if(((60*i+1)/17)%17 == 0)
//         cout<<i<< " ";
//         // break;
//     }
//     return 0;
// }
