#include<iostream>
#include<climits>
using namespace std;

class Node{
public:
    int val;
    Node* left;
    Node* right;
    Node(int val) {
        this->val=val;
        this->right=NULL;
        this->left=NULL;
    } 
};

void display(Node* root , int  l , int cl) {
    if(root == nullptr) return;
    // cout<<
    if(l == cl)
    {
        cout<<root->val<<" ";
    }
    display(root->left , l+1 , cl);
    display(root->right , l+1 , cl);
}

int main() {
    Node* a = new Node(10);
    Node* b = new Node(20);
    Node* c = new Node(30);
    Node* d = new Node(40);
    Node* e = new Node(50);
    Node* f = new Node(60);
    Node* g = new Node(70);
    Node* h = new Node(80);
    Node* i = new Node(90);
    Node* j = new Node(100);
    Node* k = new Node(110);


    a->left=b;
    a->right=c;
    b->left=d;
    b->right=e;
    d->left=f;
    d->right=g;
    e->left=h;
    e->right=i;
    f->left=j;
    f->right=k;

    cout<<endl;

    int l = 0;
    int cl = 4;
   display(a , l , cl);

}