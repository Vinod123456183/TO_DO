import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Declaring and creating an array of integers
        int[] numbers = new int[5];

        // Taking input from the user for array elements
        System.out.println("Enter 5 integers:");
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = scanner.nextInt();
        }

        // Accessing array elements
        System.out.println("First element: " + numbers[0]);
        System.out.println("Last element: " + numbers[numbers.length - 1]);

        // Modifying an array element
        System.out.println("Enter the index to modify (0-4):");
        int index = scanner.nextInt();
        System.out.println("Enter the new value:");
        int newValue = scanner.nextInt();
        numbers[index] = newValue;

        // Printing the array elements
        System.out.println("\nArray elements:");
        for (int i = 0; i < numbers.length; i++) {
            System.out.println(numbers[i]);
        }

        // Initializing an array during declaration
        String[] names = {"Alice", "Bob", "Charlie", "David", "Eve"};

        // Printing the array elements
        System.out.println("\nNames:");
        for (String name : names) {
            System.out.println(name);
        }

        // Multidimensional array
        int[][] matrix = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};

        // Accessing elements of a multidimensional array
        System.out.println("\nMatrix element (1, 2): " + matrix[1][2]);

        scanner.close();
    }
}