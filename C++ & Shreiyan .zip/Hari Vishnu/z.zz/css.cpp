#include <iostream>
#include <vector>

using namespace std;

class Solution {
public:
    void f(int idx, vector<vector<int>>& ans, vector<int>& temp, int k, int n) {
        if (n == 0 && k == 0) {
            ans.push_back(temp);
            return;
        }

        for (int i = idx; i <= 9; i++) {
            if (n - i < 0) {
                // If n - i becomes negative, skip the current iteration to avoid invalid combinations.
                continue;
            }

            temp.push_back(i);
            f(i + 1, ans, temp, k - 1, n - i);
            temp.pop_back();
        }
    }

    vector<vector<int>> combinationSum3(int k, int n) {
        vector<vector<int>> ans;
        vector<int> temp;

        f(1, ans, temp, k, n);

        return ans;
    }
};

int main() {
    Solution solution;
    
    int k = 3;  // Number of elements in each combination
    int n = 7;  // Target sum

    vector<vector<int>> result = solution.combinationSum3(k, n);

    // Print the result
    for (const auto& combination : result) {
        cout << "[ ";
        for (int num : combination) {
            cout << num << " ";
        }
        cout << "]" << endl;
    }

    return 0;
}
