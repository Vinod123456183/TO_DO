#include <bits/stdc++.h>
 using namespace std;
int main(){
    // int level = 0 , x = 10;
    // while(x--) {
        
    //     cout<<level<<" ";
    //     level =! level;
    //     // if(level & 1)cout<<"0 ";
    //     // else cout<<" 1";
    //     // level++;
    //     cout<<level<<" ";
    // }
    // return 0;
    int ans = 1<<10;
    cout<<ans;
}