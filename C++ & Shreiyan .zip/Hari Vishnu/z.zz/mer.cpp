#include <bits/stdc++.h>
 using namespace std;

class A{
    // protected:
        int x ;
    public:
    
    void input(){
        cout<<"Enter x";
        cin>>x;
    }
    int xx(){return x;}

};

class B : public A{
    public:
    int y;
    public:
    void get() {
        cout<<"Enter Y";
        cin>>y;
    }
    void ans() {
        cout<<xx()+y<<endl;
    }
};

int main(){
    B aa;
    aa.input();
    aa.get();
    aa.ans();
}