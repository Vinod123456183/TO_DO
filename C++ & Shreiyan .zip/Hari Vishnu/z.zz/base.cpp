// #include <bits/stdc++.h>
//  using namespace std;
// int main(){
//     int num = 12345;
//       int ans = 0;
//     int i = 0;

//     while (num != 0)
//     {
//         int rem = num %3;
//         ans = ans + rem * pow(10, i);
//         i++;
//         num = num /3;
//     }

//     cout << ans+2;

// }



#include <bits/stdc++.h>
 using namespace std;
int main(){
    int n = 10;
    
 int negBase = -2;
            if (n == 0)
        cout<< "0";
 
    string converted = "";
    while (n != 0)
    {
        
        int remainder = n % negBase;
        n /= negBase;
        if (remainder < 0)
        {
            remainder += (-negBase);
            n += 1;
        }
 
      
        converted = to_string(remainder) + converted;
    }
 
    cout << converted;

    return 0;
}