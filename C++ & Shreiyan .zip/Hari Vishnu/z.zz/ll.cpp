#include <iostream>
using namespace std;
class Node {
public:
    int data;       // Data stored in the node
    Node* next;     // Pointer to the next node in the list
    Node(int value) : data(value), next(nullptr) {}
};

class LinkedList {
private:
    Node* head;  
public:
    LinkedList() : head(nullptr) {}
    void addNode(int value) {
        if (head == nullptr) {
            head = new Node(value);
        } else {
            Node* current = head;
            while (current->next != nullptr) {
                current = current->next;
            }
            current->next = new Node(value);
        }
    }
    void printLinkedList() {
        Node* slow = head;
        Node* fast = head;
        while (fast != NULL and fast->next != nullptr) {
            cout <<slow -> data << " ";
            slow=slow->next;
            fast =fast->next ->next;
        }
        cout << endl;
        cout <<" " << slow->data << endl;
        cout << fast -> data<<" ";
    }
    void printLinkedList__() {
        Node* slow = head;
        Node* fast = head;
        while (fast->next != NULL and fast->next->next != nullptr) {
            cout <<fast-> data << " ";
            slow=slow->next;
            fast =fast->next->next;
        }
        cout << endl;
        cout <<" " << slow->next->data << endl;
        cout << fast -> data<<" ";
    }
};


int main() {

    LinkedList myList;

    myList.addNode(1);
    myList.addNode(2);
    myList.addNode(3);
    myList.addNode(4);
    myList.addNode(5);
    myList.addNode(6);
    myList.addNode(7);
    // myList.addNode(8);
    // myList.addNode(9);
    // myList.addNode(10);
    // myList.addNode(11);
    // myList.addNode(12);
    // myList.addNode(13);
    // myList.addNode(14);
    // myList.addNode(15);
    // myList.addNode(16);
    // myList.addNode();
    // myList.addNode();
    // myList.addNode();
    // myList.addNode();
    // myList.addNode();
    // myList.printLinkedList();
    cout << endl;
    myList.printLinkedList__();
    
}