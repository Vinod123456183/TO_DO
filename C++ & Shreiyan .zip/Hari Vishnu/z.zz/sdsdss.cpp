#include<iostream>

#include<bits/stdc++.h>

using namespace std ;

int main ()   {

    unordered_map<char , int > mp ;

    mp['j']=1;

    cout<<mp['j'];
}