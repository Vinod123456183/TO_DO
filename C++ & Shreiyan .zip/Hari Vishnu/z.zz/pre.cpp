// // #include <bits/stdc++.h>
// //  using namespace std;
// //  class Node{
// //     int val;
// //     Node*left=nullptr;
// //     Node*right=nullptr;
// //     Node(int val) {
// //         this->val=val;
// //         this->left=nullptr;
// //         this->right=nullptr;
// //     }
// // };
// // int main(){
// //     Node* a = new Node(10);
// //     Node* b = new Node(20);
// //     Node* c = new Node(30);
// //     Node* d = new Node(40);
// //     Node* e = new Node(50);
// //     a->left=b;
// //     a->right=c;
    
// // }
// #include<bits/stdc++.h>
// using namespace std;
// int main(){
//     // if(0 && 1) cout<<"1";
//     // if(1 && 0) cout<<"2";
//     // if(1 && 0) cout<<"3";
//     // if(0 && 1) cout<<"4";
//     // if(1 && 1) cout<<"5";
//     // if(0 && 0) cout<<"6";
// }

#include <bits/stdc++.h>
using namespace std;
int main(){
    // int arr[]={1,2,3,4};
    vector<int>arr = {10,5,15,3,7};
    int sum = 0;
    int i=0;
    while(sizeof(arr)/sizeof(arr[0])--){
        for(int i=0; i<arr.size();i++){
        if(arr[i]>=7 && arr[i] <= 15)
            sum += arr[i];
            // i++;
    }
    cout<<sum;
    return 0;
}