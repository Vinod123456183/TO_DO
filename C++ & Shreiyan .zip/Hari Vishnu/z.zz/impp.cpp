// #include <bits/stdc++.h>
//  using namespace std;

// int xxx(int x , int n) {
//     if(n == 0) return 1;
//     return x * xxx(x,n-1);
//     // cout<<n<<"  "; 
// }
// int main(){
//     cout<<xxx(2,9);
//     return 0;
// }
// /*/*
// class Solution {
// public:
//     double myPow(double N, int n) {
//         double i = 1;
//     while( N >= n*n){
//         i++;
//     }
//     return i-1;
    
//     }
// };
// */



// /**
//  * 
//  * class Solution {
// public:
//     bool isPowerOfTwo(int n) {
//         // method 1 Bit Manupulation
//         // double i = log(n) / log(2);
//         // return i == trunc(i);

//             //method 2 recursion
//         // if(n==1) return true;
//         // if(n==0 || n%2!=0) return false;
//         // return isPowerOfTwo(n/2);

//         // // method 3
//         // return !(n & (n - 1))&& (n % 3 == 1);

//         // 
//             double i = log(n) / log(2);
//             return i - trunc(i) < 0.000001;
//     }
// };
// */


#include <iostream>

int main() {
    long long result = 282429536481%353;
    std::cout << "729 mod 353 is: " << result << std::endl;

    return 0;
}