#include <stdio.h>
#include <stdlib.h>

// Define a Node structure for the linked list
struct Node {
    int data;
    struct Node* next;
};

// Function to merge two linked lists alternately using a loop and a variable i
struct Node* mergeAlternately(struct Node* A, struct Node* B) {
    struct Node* head = NULL;
    struct Node* tail = NULL;
    int i = 1; // Variable i to track odd/even conditions

    while (A != NULL && B != NULL) {
        struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
        newNode->next = NULL;

        newNode->data = (i % 2 == 1) ? A->data : B->data;

        if (head == NULL) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }

        if (i % 2 == 1) {
            A = A->next;
        } else {
            B = B->next;
        }

        i++;
    }

    // Append remaining elements from A if any
    while (A != NULL) {
        struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
        newNode->data = A->data;
        newNode->next = NULL;

        tail->next = newNode;
        tail = newNode;

        A = A->next;
    }

    // Append remaining elements from B if any
    while (B != NULL) {
        struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
        newNode->data = B->data;
        newNode->next = NULL;

        tail->next = newNode;
        tail = newNode;

        B = B->next;
    }

    return head;
}

// Function to print a linked list
void printList(struct Node* node) {
    while (node != NULL) {
        printf("%d ", node->data);
        node = node->next;
    }
    printf("\n");
}

// Function to free the memory allocated for a linked list
void freeList(struct Node* node) {
    struct Node* temp;
    while (node != NULL) {
        temp = node;
        node = node->next;
        free(temp);
    }
}

int main() {
    // Example linked lists A and B
    struct Node* A = NULL;
    struct Node* B = NULL;

    // Append elements to linked lists A and B
    A = (struct Node*)malloc(sizeof(struct Node));
    A->data = 1;
    A->next = (struct Node*)malloc(sizeof(struct Node));
    A->next->data = 3;
    A->next->next = (struct Node*)malloc(sizeof(struct Node));
    A->next->next->data = 5;
    A->next->next->next = NULL;

    B = (struct Node*)malloc(sizeof(struct Node));
    B->data = 2;
    B->next = (struct Node*)malloc(sizeof(struct Node));
    B->next->data = 4;
    B->next->next = (struct Node*)malloc(sizeof(struct Node));
    B->next->next->data = 6;
    B->next->next->next = (struct Node*)malloc(sizeof(struct Node));
    B->next->next->next->data = 8;
    B->next->next->next->next = NULL;

    // Create a new linked list S containing elements alternately from A and B
    struct Node* S = mergeAlternately(A, B);

    // Print the merged linked list S
    printf("Merged Linked List S: ");
    printList(S);

    // Free the memory allocated for the linked lists
    freeList(A);
    freeList(B);
    freeList(S);

    return 0;
}
