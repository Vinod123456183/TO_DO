#include <iostream>
using namespace std;

int main() {
    int n;

    cout << "Enter a positive number: ";
    cin >> n;

    // Check if the number is positive
    if (n <= 0) {
        cout << "Invalid input! Please enter a positive number." << endl;
        goto end; // Jump to the end label to terminate the program
    }

    // Loop using a for loop
    for (int i = 1; i <= n; i++) {
        if (i % 2 == 0) {
            cout << i << " is even." << endl;
        } else {
            cout << i << " is odd." << endl;
        }

        // Check if the number is 5 and use goto to exit the loop
        if (i == 5) {
            cout << "Encountered the number 5. Exiting loop." << endl;
            goto end; // Jump to the end label to terminate the program
        }
    }

    // Label to end the program
    end:
    cout << "End of program." << endl;
    return 0;
}
