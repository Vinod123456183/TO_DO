#include <bits/stdc++.h>
 using namespace std;
int main(){
    // string n1="12";
    // string n2="123";
    //     int num1 = n1[0] - '0';
    // // int num1 = int(n1);
    // // int num2 = int(n2);
    // int num2 = n2[n2.length()-1] - '0';
    // cout<<num1+2;
    // return 0;

    int n = 81;
    int i=1;
     while(i*i<=n){
        i++;
     }
     cout<<i-1;
}