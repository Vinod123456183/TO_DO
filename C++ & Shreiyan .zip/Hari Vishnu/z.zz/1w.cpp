#include <iostream>
#include <vector>
using namespace std;

bool canSplitArray(int ind, vector<int> &arr, int sum1, int sum2) {
    if (ind == arr.size()) {
        return (sum1 == sum2);
    }

    // Include the current element in the first subset
    if (canSplitArray(ind + 1, arr, sum1 + arr[ind], sum2)) {
        return true;
    }

    // Include the current element in the second subset
    if (canSplitArray(ind + 1, arr, sum1, sum2 + arr[ind])) {
        return true;
    }

    return false;
}

int main() {
    vector<int> arr = {1, 5, 121, 5};

    int totalSum = 0;
    for (int num : arr) {
        totalSum += num;
    }

    if (totalSum % 2 != 0) {
        cout << "Array cannot be split into two equal sum subarrays." << endl;
    } else {
        if (canSplitArray(0, arr, 0, 0)) {
            cout << " can be split into two equal sum subarrays." << endl;
        } else {
            cout << "Array cannot be split into two equal sum subarrays." << endl;
        }
    }

    return 0;
}
