#include <bits/stdc++.h>
using namespace std;
   int sum (int arr[] , int x , int i, int s)  {
    
        if(i == s) return arr[i-1];
        return  max( arr[i] , sum(arr, x , i+1 , s));

   }
int main(){
    int x = 0;
    int arr[]={10,12,11134,1005};
   cout<< sum(arr , x , 0 , 4);
    
}