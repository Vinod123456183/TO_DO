#include <bits/stdc++.h>
 using namespace std;
int main(){
    vector<int>nums;
    nums.push_back(9);
    nums.push_back(4);
    nums.push_back(0);
    nums.push_back(1);
     int low = 0;
        int  high = nums.size();
        while(low < high) {
            if(nums[low]>nums[high]){
                swap(nums[low++],nums[high--]);
            }
            low++;high--;
        }
        for(int i=0;i<nums.size();i++) cout<<nums[i]<<" ";
}