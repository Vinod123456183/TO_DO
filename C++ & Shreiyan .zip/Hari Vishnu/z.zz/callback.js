const a =  (a,b) => a+b
const d =  (a,b) => a/b
const calculate=(a , b , operation) => (operation(a,b))
console.log(calculate(2,2,a));
console.log(calculate(2,2,d));








// function add(a, b) {
//     return a + b;
// }
// function divide(a, b) {
//     return a / b;
// }
// function calculate(a, b, operation) {
//     return operation(a, b);
// }
// console.log(calculate(2, 2, add));
// console.log(calculate(2, 2, divide));
