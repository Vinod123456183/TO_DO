#include <bits/stdc++.h>
 using namespace std;
int main(){
    string s = "geeks3";
    int n = s.size()-1;
    cout<<('a'^'c');
    return 0;
}