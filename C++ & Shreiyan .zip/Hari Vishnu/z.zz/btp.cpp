#include<bits/stdc++.h>

using namespace std;

class Node{

    int data;
    Node* left ;
    Node* right;

    Node(int data) {

        this->data=data;
        this->left=NULL;
        this->right=nullptr;

    }

};

int main() {


    Node* root = new Node(10);

    Node* a = new Node(20);

}