#include <iostream>

int findSplitPoint(int arr[], int n) 
{ 
    int leftSum = 0; 
  
    // Traverse array elements 
    for (int i = 0; i < n; i++) 
    { 
        // Add the current element to the left sum 
        leftSum += arr[i]; 
  
        // Find the sum of the remaining array elements (rightSum) 
        int rightSum = 0; 
        for (int j = i + 1; j < n; j++) 
            rightSum += arr[j]; 
  
        // Check if the leftSum is equal to the rightSum 
        if (leftSum == rightSum) 
            return i + 1;  // Split point index
    } 
  
    // If it is not possible to split the array into two parts 
    return -1; 
}

int main() 
{
    int arr[] = {4, 1, 2, 3};
    int n = sizeof(arr) / sizeof(arr[0]);

    int splitPoint = findSplitPoint(arr, n);

    if (splitPoint != -1) {
        std::cout << "Array can be split into two parts at index " << splitPoint << std::endl;
    } else {
        std::cout << "It is not possible to split the array into two parts." << std::endl;
    }

    return 0;
}
