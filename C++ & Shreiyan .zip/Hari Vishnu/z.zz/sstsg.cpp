#include <bits/stdc++.h>
using namespace std;

int main()   {

    vector<int>v = {1,2,3,4,5,6,7};
    int k = 3;

    reverse(v.begin(),v.end()-k);
    reverse(v.end()-k,v.end());

for(int i= 0 ; i <v.size(); i++)
    cout<<v[i]<<"  ";
}
