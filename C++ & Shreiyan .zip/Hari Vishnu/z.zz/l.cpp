





#include<iostream>
using namespace std;

class Node{
public: 
    int val;
    Node* next;
    Node(int val){
        this->val = val;
        this->next = NULL;
    }
};

int main(){
    Node * one = new Node(10);
    Node * two = new Node(20);
    Node * three = new Node(30);

    one->next=two;
    two->next=three;
    Node* temp , *zz = one;


    Node* newNode = new Node(1);
                newNode->next = one->next;
            one->next = newNode;
            one = newNode->next;
    // one = temp;
    while(zz!=NULL) {
        cout<<zz->val<<" ";
        zz=zz->next;
    }
}