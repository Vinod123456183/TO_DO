#include <bits/stdc++.h>
using namespace std;
int main(){
    vector<int>q = {1,2,3};
    vector<int>w = {1,1,1,2,3};

int ans = 0;
    for(int i = 0; i<q.size(); i++)  {

        for(int j = 0 ; j  < w.size ()   ; j ++)
         {

            if(q[i] == w[j])ans++;
         }
    }
cout<<ans;
    
    
}