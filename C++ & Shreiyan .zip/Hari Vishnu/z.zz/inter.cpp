#include<bits/stdc++.h>
 
using namespace std;
vector<int> findIntersection(const vector<int>& vec1, const vector<int>& vec2) {
    unordered_map<int, int> mp;
    vector<int> intersection;

    // Populate the hashmap with elements from vec2
    for (int num : vec2) {
        mp[num]++;
    }

    // Check elements from vec1 if they are in vec2
    for (int num : vec1) {
        if (mp.find(num) != mp.end()) {
            intersection.push_back(num);
        }
    }
    return intersection;
}

int main() {
    // Example usage
    vector<int> vec1 = {9 , 6 , 4 , 2, 3 , 8};
    vector<int> vec2 = {1,2,8,6};
    vector<int> intersection = findIntersection(vec1, vec2);

    cout << "Intersection elements: ";
    for (int num : intersection) {
        cout << num << " ";
    }
    cout << endl;
}
