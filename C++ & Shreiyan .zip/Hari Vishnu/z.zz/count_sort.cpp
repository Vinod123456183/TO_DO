// Do Dry Run Again


#include<bits/stdc++.h>
using namespace std;
int main()  {
    vector<int>nums={9,4,1,1,10,1};
    int maxVal = *max_element(nums.begin(),nums.end());
    int minVal = *min_element(nums.begin(),nums.end());
    int range = maxVal-minVal+1;
cout << endl <<range ;
    vector<int>count(range,0);

    for(int num : nums) {
        count[num-minVal]++;
    }

    for(int i=0; i<count.size(); i++) {
        cout << count[i] << ' ' ;
    }

    cout << endl ;

    for(int i = 1; i < range ; i++)  {
        count[i] += count[i-1];
    }

    for(int i=0; i<count.size(); i++) {
        cout << count[i] << ' ' ;
    }

    cout << endl ;

    vector<int>sorted(nums.size(),0);
    // for(int i = nums.size()-1 ;i >= 0; i--) {
    //     sorted[count[nums[i]-minVal]-1]=nums[i];
    // }
        cout << endl <<"Rand is :" <<  count[0] << endl ;
        cout << endl <<"Rand is :" <<  nums[5]-minVal << endl ;
    int rand = 0; 
    for(int i = nums.size()-1 ;i >= 0; i--) {
        rand = count[nums[i]-minVal]-1;
        sorted[count[nums[i]-minVal]-1]=nums[i];
        count[nums[i]-minVal]--;
    } 
        cout << endl <<"Rand is :" <<  rand << endl ;
    
    for(int i=0; i<nums.size(); i++) {
        cout << nums[i] << ' ' ;
    }

    cout << endl ;

    for(int i=0; i<sorted.size(); i++) {
        cout << sorted[i] << ' ' ;
    }

    cout << endl ;
    

}