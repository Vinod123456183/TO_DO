#include <bits/stdc++.h>
 using namespace std;
int main(){
    vector<int>nums = {2,2,2,1,2,2,1,2,2,2};
        for(int i = 0; i < nums.size(); i++)
        {
            if(nums[i] % 2 == 1) nums[i] = 1;
            else nums[i] = 0;
        }

    for(int i=0; i<nums.size(); i++)
        cout<<nums[i]<<" ";
}  
