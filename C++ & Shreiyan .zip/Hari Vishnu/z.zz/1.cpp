// // #include <bits/stdc++.h>
// //  using namespace std;
// // int main(){
// //     string s = "abcdefghijkl";
// //     int l =0;
// //     int r=s.size()-1;
// //     reverse(s.begin()+l,s.begin()+r);
// //     cout<<s;
// //     return 0;
// // }

// // #include <bits/stdc++.h>
// //  using namespace std;
// // int main(){
// //     string  arr[] = {"geeksforgeeks", "geeks", "geek",
// //          "geezer"};

// //     sort(arr,arr+4);
// //     cout<<arr[0];
// // }

// #include <bits/stdc++.h>
//  using namespace std;
// int main(){
//     vector<int>v={1,2,3,4,5,6};
//     cout<<v[v.size()/2-1];//when size is evenn or odd but wawnt to print mid,mid se phele
//     cout<<v[v.size()/2+1];//when size is evenn or odd but wawnt to print mid,mid k baad
//     return 0;
// }

#include <bits/stdc++.h>
using namespace std;
int main(){
  string s = "abcd";
  string t = "defg";
  unordered_map<char , int>mp;
  for(auto it : s)
    mp[it]++;
for(auto it : t)
    mp[it]--;

for(auto x : mp){
    cout<<x.first<<x.second<<endl;
    // cout<<it.second<<endl;
}
    
    return 0;
}