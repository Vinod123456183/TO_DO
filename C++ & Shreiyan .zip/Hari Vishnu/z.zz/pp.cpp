#include <bits/stdc++.h>
using namespace std;
int main(){
    vector<int>nums = {10,4,8,3,7};

     vector<int>l;
            vector<int>r;

        l.push_back(0);

        for(int i=0;i<l.size(); i++){

            l.push_back(l[i] + nums[i]);

        }



        for(int i=0;i<l.size(); i++)cout<<l[i]<<" ";

    return 0;
}