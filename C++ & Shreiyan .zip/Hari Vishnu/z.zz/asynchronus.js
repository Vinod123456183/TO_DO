console.log("Start");
// Asynchronous operation using setTimeout

setTimeout(() => {
    console.log("Inside setTimeout, after 2 seconds");
}, 2000);

console.log("End");


// console.log("Start");
// // Asynchronous operation using setTimeout

// setTimeout(function() {
//     console.log("Inside setTimeout, after 20 seconds");
// }, 20000);

// console.log("End");
