
// #include <bits/stdc++.h>
// using namespace std;
// int main(){
//   string s = "leetcode";
//   string t = "coats";
//   unordered_map<char , int>mp;
//   for(auto it : s)
//     mp[it]++;
// for(auto it : t)
//     mp[it]--;

// int ans = 0;
// for(auto x : mp){
//     // if(x.second>=INT_MIN)
//     ans += abs(x.second);
// }
//     cout<<ans;
//     return 0;
// }

#include <bits/stdc++.h>
 using namespace std;
int main(){
    // vector<int>ans={ -1,2,-3,5,6};
    // int ans1 = 0;

    // for(int i=0; i<ans.size(); i++)
    //     ans1=ans[0];
    // cout<<ans1;
    cout<<-10%3; 
    return 0;
}