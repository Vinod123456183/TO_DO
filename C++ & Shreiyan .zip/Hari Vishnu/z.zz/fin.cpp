// #include<bits/stdc++.h>
// using namespace std;
// int main() {
//     unordered_map<int,int>mp;
//     mp[10]=1;
//     mp[20]=2;
//     cout<<mp[20];
// }
#include<iostream>
#include<climits>
using namespace std;

class Node{
public:
    int val;
    Node* left;
    Node* right;
    Node(int val) {
        this->val=val;
        this->right=NULL;
        this->left=NULL;
    } 
};

Node* display(Node* root) {
    if(root == nullptr) return 0;
    cout<<" ";
    root->left = display(root->left);


    if(root->left == nullptr) cout <<" " <<"Y";
    // cout<<endl;
    // cout<<root->left->val << " ";
}

int main() {
    Node* a = new Node(10);
    Node* b = new Node(20);
    Node* c = new Node(3);
    Node* d = new Node(40);
    Node* e = new Node(50);
    Node* f = new Node(60);
    Node* g = new Node(70);
    Node* h = new Node(80);
    Node* i = new Node(90);
    Node* j = new Node(100);
    Node* k = new Node(110);


    a->left=b;
    a->right=c;
    b->left=d;
    b->right=e;
    d->left=f;
    d->right=g;
    e->left=h;
    e->right=i;
    f->left=j;
    f->right=k;

    cout<<endl;

   cout<< display(a);
// cout<<(k->left)<<" ";
}