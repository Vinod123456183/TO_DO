// #include <vector>
// #include <algorithm>

// class Solution {
// public:
//     int maxScore(std::vector<int>& nums, int k) {
//         int n = nums.size();
//         int totalSum = std::accumulate(nums.begin(), nums.end(), 0);

//         int windowSum = 0;
//         for (int i = 0; i < n - k; ++i) {
//             windowSum += nums[i];
//         }

//         int minWindowSum = windowSum;





//         return totalSum - minWindowSum;
//     }
// };


#include <bits/stdc++.h>
using namespace std;
int main(){
    
    vector<int>nums={1,2,3,4,5,6,1};
    int n=7 ;

    int ans = 0;

    int k = 3;
    for(int i = n-k ; i<n ; i++) {

    ans = nums[i-n+k];
    break;
    }
    cout<<ans;
}