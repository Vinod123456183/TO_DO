#include <bits/stdc++.h>
using namespace std;

void f(vector<int>& nums, vector<int>& temp, int i, int n, int sum) {
    if (i == n) {
        temp.push_back(nums);
        return;
    }

    for (int j = 0; j < n - 1; j++) {
        swap(nums[j], nums[j + 1]);
        f(nums, temp, i + 1, n, sum);
    }
}

int main() {
    vector<int> nums = {1, 2, 3};
    vector<int> temp;
    f(nums, temp, 0, nums.size(), 0);
    for (auto it : temp)
        cout << it << endl;
}
