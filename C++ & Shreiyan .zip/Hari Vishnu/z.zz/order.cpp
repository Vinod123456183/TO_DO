// check meanng of both answer 
// dry run
// do without space in O(1)
// Two Repeated Element (gfg)
// You are given an array arr of n+2 integers. 
// means n + 2 size of array


#include<bits/stdc++.h>
using namespace std;
int main() {
    unordered_map<int , int> mp;
    int arr[] = {1,2,3,4,1,2,3};
    int n =sizeof(arr)/sizeof(arr[0]);
    for(int i=0; i<n; i++) {
        mp[arr[i]]++;
        if(mp[arr[i]] == 2) {
            cout << arr[i] <<" ";
        }
    }

    cout << endl;
    for(auto it : mp) {
        if(it.second==2) {
            cout << (it.first) <<" ";
        }
    }

}



/*
    // Your code here
    boolean[] visited = new boolean[N + 2];
    int[] result = new int[2];
    int index = 0;
    
    for (int i = 0; i < arr.length; i++) {
        if (visited[arr[i]]) {
            result[index++] = arr[i];
        } else {
            visited[arr[i]] = true;
        }
    }
    
    return result;
*/



/*
vector<int> twoRepeated (int arr[], int n) {       
        vector<int> v;
        for(int i=0; i<n+2; i++)
        {
            arr[abs(arr[i])] = (-1)*arr[abs(arr[i])];
            if(arr[abs(arr[i])]>0) v.push_back(abs(arr[i]));
        }
        return v;
    }
*/


/* intra hashing

 vector<int> twoRepeated (int arr[], int N) {
       // Your code here
       vector<int> ans; 
       //this is an intra hashing way
   
       for(int i=0; i<N+2; i++){
           if(arr[abs(arr[i])] > 0){
               arr[abs(arr[i])] = -1*arr[abs(arr[i])];
           }
           else{
               ans.push_back(abs(arr[i]));
           }
       }
       return ans;
   }
*/


/*
vector<int> twoRepeated (int arr[], int N) {
       vector <int> res;
       for(int i=0;i<N+2;i++)
       {
           if(arr[abs(arr[i])]>0)
               arr[abs(arr[i])] *=-1;
           else
               res.push_back(abs(arr[i]));
       }
       return res;
   }
*/