#include<bits/stdc++.h>
using namespace std;
int main() {

    unordered_map<int,int>mp;

    vector<int>nums = {2,6,11,15};
    // int k = 9;

    mp[0] = 10;
    mp[2] = 12;

    for(auto it:mp) {
        cout<<it.first<<" "<<it.second<<endl;
    }
}