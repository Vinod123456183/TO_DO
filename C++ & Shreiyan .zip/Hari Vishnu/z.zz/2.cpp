#include <bits/stdc++.h>
using namespace std;
int main(){
    vector<int>nums = {1,1,4,4};
    unordered_map<int,int>mp;
    for(auto it : nums) 
        mp[it]++;
    
        int x ,ans = 0;
    for(auto i = mp.begin(); i!=mp.end(); i++){
        if(ans <  i->second ){

            ans = i->second;
            x=i->first;
        }        
    }
    cout<<ans<<x;
   
}