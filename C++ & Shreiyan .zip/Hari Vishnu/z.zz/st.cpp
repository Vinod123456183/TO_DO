// #include <bits/stdc++.h>
// using namespace std;
// int main(){
// vector<int>res={10,2,-7};
// // cout<<" ans "<<res.back()<<"__";
// int i=0;
//                         i--;
//                         res.pop_back();
//                         cout<<res[0]<<res[2]<<res[2];
// // cout<<res[-1];
// }  

// #include <bits/stdc++.h>
//  using namespace std;
// int main(){
//     int k=5;
//    if (k) {
//         while (k--) 
//             cout<<"hi"<<endl;
        
//     }
// }


// #include <bits/stdc++.h>
//  using namespace std;
// int main(){
//     vector<int>ans = {1,3,4};
//     // cout<<ans.back();
//     cout<<islower(ans[0]);
    
//     return 0;
// }

#include <bits/stdc++.h>
 using namespace std;
int main(){
    // int N=10;
    // int B=-2;
    //  string ans="";
    //     string alpha = "ABCDEF";
    //     while(N) {
    //         if(N%B > 9)
    //             ans = alpha[(N%B)%10] + ans;
    //         else 
    //             ans = to_string(N%B) + ans;
    //         N/=B;
    //     }
    //     cout<< ans <<" ";
    // return 0;

    // int ans = 0;int num=62;
    //     int i = 0;
    //     while (num != 0){
    //         int rem = num % 2;
    //         ans = ans + rem * pow(10, i);
    //         i++;
    //         num = num / 2;
    //     }

    //     cout << to_string(ans);

    // int n = 10;
    // string res = "";
    // while(n--) {
    //     int rem = n % 2;
    //     n /=2;
    //     if(rem<0) {
    //         rem += 2;
    //         n += 1;
    //     }
    //     res += to_string(rem);
    //     cout<<res;
    // }


// string s="*";
// int N=2;
//         for(int i=0;i<N;i++)
//         // while(N--)
//         {
//             cout<<s<<" ";
//             s+="*";
//         }
//         cout<<s<<" ";


// for(int i=1; i<11; i++) {
    // int n=11;
//     while(n--){
//     cout<<"10"<<" ";
// }

    // int arr[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,1132};
    // for(int i=0; i<16; i++) {
    //     if(i%15 == 0)
    //         cout<<arr[i]<<" ";
    // }

    // int n=6;
    // while(n) {
    //     cout<<n<<" ";
    //     n--;
    // }
    vector<int>pos={1,};
    vector<int>neg={-1,-2,-3};
    vector<int>ans;
    int arr[pos.size()+neg.size()];
    int i = 0, j = 0, k = 0;
        while (i < pos.size() && j < neg.size()) {
            ans.push_back(pos[i++]);
            ans.push_back( neg[j++]);
        }
    
        while (i < pos.size()) {
            ans.push_back(pos[i++]);
        }
    
        while (j < neg.size()) {
            ans.push_back( neg[j++]);
        }
    // for(auto it:ans)
    for(int i=0; i<ans.size(); i++)
    cout<<ans[i]<<" ";
}