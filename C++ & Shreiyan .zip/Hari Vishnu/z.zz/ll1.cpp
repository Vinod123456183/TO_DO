#include <iostream>

// Define the structure of each node in the linked list
class Node {
public:
    int data;       // Data stored in the node
    Node* next;     // Pointer to the next node in the list

    // Constructor to initialize data and next pointer
    Node(int value) : data(value), next(nullptr) {}
};

// Define the LinkedList class
class LinkedList {
private:
    Node* head;     // Pointer to the first node in the list

public:
    // Constructor to initialize the head pointer
    LinkedList() : head(nullptr) {}

    // Function to add a new node to the end of the list
    void addNode(int value) {
        if (head == nullptr) {
            head = new Node(value);
        } else {
            Node* current = head;
            while (current->next != nullptr) {
                current = current->next;
            }
            current->next = new Node(value);
        }
    }

        void simple() {
        Node* current = head;   // Start from the head of the list
        while (current != NULL and current->next != NULL) {
            std::cout << current->data << " ";   // Print the data of the current node
            current = current->next;              // Move to the next node
        }
        std::cout << std::endl;
        std::cout << current->data << std::endl;
    }

    void printLinkedList() {
        Node* current = head;   // Start from the head of the list
        while (current != NULL and current->next!= nullptr) {
            std::cout << current->data << " ";   // Print the data of the current node
            current = current->next;              // Move to the next node
        }
        std::cout <<"- =  " << current->data << std::endl;

        std::cout << std::endl;
    }
    void printLinkedList1() {
        Node* current = head;   // Start from the head of the list
        while (current->next != NULL and current->next->next != nullptr) {
            std::cout << current->data << " ";   // Print the data of the current node
            current = current->next;              // Move to the next node
        }
        std::cout << std::endl;
    }
    void printLinkedList2() {
        Node* current = head;   // Start from the head of the list
        while (current->next->next != NULL and current->next->next->next != nullptr) {
            std::cout << current->data << " ";   // Print the data of the current node
            current = current->next;              // Move to the next node
        }
        std::cout << "```````````" << current->data <<  std::endl;
        std::cout << std::endl;
    }


    // Destructor to free memory allocated for nodes
    ~LinkedList() {
        Node* current = head;
        while (current != nullptr) {
            Node* temp = current;
            current = current->next;
            delete temp;
        }
    }
};

// Using namespace directive to avoid writing std:: prefix
using namespace std;

int main() {
    // Creating a linked list object
    LinkedList myList;

    // Adding elements to the linked list
    myList.addNode(1);
    myList.addNode(21);
    myList.addNode(22);
    myList.addNode(23);
    myList.addNode(24);
    myList.addNode(25);
    myList.addNode(27);

    // Printing the linked list
    // cout << "S: " << endl;
    myList.simple();
    
}