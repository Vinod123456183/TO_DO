        // -1 0 -1 2 -1 4
        // 1 6 4 4 6 6 
        // -1 -1 1 2 1 4
  #include <iostream>
#include <vector>
#include <stack>

std::vector<int> previousSmallerIndex(const std::vector<int>& nums) {
    int n = nums.size();
    std::vector<int> result(n, -1);  // Initialize with -1, indicating no smaller element found yet
    std::stack<int> st;  // Stack to store indices

    for (int i = n - 1; i >= 0; --i) {
        while (!st.empty() && nums[st.top()] > nums[i]) {
            result[st.top()] = i;
            st.pop();
        }
        st.push(i);
    }

    return result;
}

int main() {
    // Example usage:
    // std::vector<int> input = {4, 5, 2, 10, 8};
    std::vector<int>input = {2,1,5,6,2,3};
    std::vector<int> output = previousSmallerIndex(input);

    // Output the result
    // std::cout << "Input: {4, 5, 2, 10, 8}\n";
    std::cout << "Previous smaller indices: ";
    for (int index : output) {
        std::cout << index << " ";
    }
    std::cout << "\n";

    return 0;
}

        // for(auto it : ans )cout<<it<<" 