// #include<bits/stdc++.h>
// using namespace std;
// int main() {
//     vector<int>v = {1,2,1,5,4} ;
//     unordered_map<int,int>mp;

//     for(auto it : v)  {
//         mp[v[it]]++;
//     }
//     cout<<mp.size(); 
// }



#include<bits/stdc++.h>
using namespace std ;

int main ()  {
    unordered_map<int, int> mp;
    vector<int> intersection;    
    vector<int> vec1 = {9 , 6 , 4 , 2,2, 3 , 8};
    for (int num : vec1) {
        mp[num]++;
    }

    for(auto it : mp) {
        cout << it.first<< " - " << it.second << endl;
    }
}