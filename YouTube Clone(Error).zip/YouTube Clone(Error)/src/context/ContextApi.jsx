import React, { createContext, useState, useEffect } from "react";

import { fetchDataFromApi } from "../utils/Apii";

// used in header file
export const Context = createContext();

export const AppContext = (props) => {
  const [loading, setLoading] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("New");
  const [mobileMenu, setMobileMenu] = useState(false);

  useEffect(() => {
    fetchSelectedCategoryData(selectedCategory);
  }, [selectedCategory]);

  const fetchSelectedCategoryData = (query) => {
    setLoading(true);
    fetchDataFromApi(`search/?q=${query}`).then(({ contents }) => {
      console.log(contents);

      setLoading(false);
    });
  };

  return (
    <Context.Provider
      value={{
        setLoading,
        searchResults,
        selectedCategory,
        setSelectedCategory,
        loading,
        mobileMenu,
        setMobileMenu,
      }}
    >
      {props.children}
    </Context.Provider>
  );
};
