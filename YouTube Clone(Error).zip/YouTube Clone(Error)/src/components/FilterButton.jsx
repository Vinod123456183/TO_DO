import React, { act, useState } from "react";

function FilterButton({ text, onClick }) {
  const [active, setActive] = useState(false);

  const handleClick = () => {
    setActive(!active);
    onClick();
  };

  return (
    <>
      <button
        className={`rounded-xl  px-4  cursor-pointer transition-all duration-300 ${
          active
            ? "bg-[#ffffff] opacity-95  text-black"
            : "text-[#c6c6c6] bg-[#121111]"
        }`}
        onClick={handleClick}
      >
        {text}
      </button>
    </>
  );
}

export default FilterButton;
