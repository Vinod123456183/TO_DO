import React, { useState } from "react";
import {
  FaCrosshairs,
  FaMendeley,
  FaSearch,
  FaVoicemail,
} from "react-icons/fa"; // Using react-icons for icons

import LeftMenu from "../components/LeftMenu";

function Header() {
  // State to toggle LeftMenu visibility
  const [isMenuVisible, setIsMenuVisible] = useState(false);

  // Toggle the visibility of LeftMenu
  const handleMenuToggle = () => {
    setIsMenuVisible(!isMenuVisible);
  };

  return (
    <div className="flex">
      {/* Conditionally render LeftMenu with sliding effect */}
      <div
        className={`fixed left-0 top-0 w-[250px] h-full bg-gray-500 text-white p-3 transform transition-transform duration-300 ${
          isMenuVisible ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* Pass handleCloseMenu function to LeftMenu */}
        <LeftMenu onClose={handleMenuToggle} />
      </div>

      {/* Main content area */}
      <div
        className={`flex-1 transition-all duration-300 ${
          isMenuVisible ? "ml-[250px]" : "ml-0"
        }`}
      >
        <div className="flex p-3 justify-between items-center px-5">
          {/* Left section */}
          <div className="flex gap-4 items-center justify-center">
            <div>
              {/* Toggle LeftMenu when FaMendeley is clicked */}
              <FaMendeley
                className="cursor-pointer"
                onClick={handleMenuToggle}
              />
            </div>
            <div className="cursor-pointer">Logo</div>
          </div>

          {/* Search and Icons section */}
          <div className="flex gap-4 items-center justify-end">
            <div className="flex gap-3 w-[500px] items-center border rounded-xl border-blue-50 px-3 py-2">
              <input
                type="text"
                placeholder="Search"
                className="outline-none bg-transparent w-full "
              />
              <FaCrosshairs className="text-gray-500 cursor-pointer" />
              <FaSearch className="text-gray-500 cursor-pointer" />
            </div>
            <div>
              <FaVoicemail />
            </div>
          </div>

          {/* Right section */}
          <div className="flex gap-4 items-center justify-center">
            <div>Add</div>
            <div>Acc</div>
          </div>
        </div>
      </div>
    </div>
  );
}

/*
        className={`flex-1 transition-all duration-300 ${
          isMenuVisible ? "ml-[250px]" : "ml-0"
        }`}
*/

export default Header;
