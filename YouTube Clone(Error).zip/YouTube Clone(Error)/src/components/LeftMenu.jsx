import React from "react";
import {
  FaTimes,
  FaHome,
  FaTv,
  FaListAlt,
  FaMusic,
  FaFilm,
  FaBasketballBall,
  FaShoppingCart,
  FaPodcast,
} from "react-icons/fa"; // Importing different icons for each section
import AsideDiv from "./AsideDiv"; // Assuming AsideDiv is a reusable component

function LeftMenu({ onClose }) {
  // List of sections and their menu items
  const mainMenuItems = [
    { Logo: <FaHome size={20} />, name: "Home" },
    { Logo: <FaTimes size={20} />, name: "Shorts" },
    { Logo: <FaListAlt size={20} />, name: "Subscription" },
  ];

  const userItems = [
    { Logo: <FaTv size={20} />, name: "History" },
    { Logo: <FaTv size={20} />, name: "Playlists" },
    { Logo: <FaTv size={20} />, name: "Your videos" },
    { Logo: <FaTv size={20} />, name: "Watch later" },
    { Logo: <FaTv size={20} />, name: "Liked videos" },
  ];

  const exploreItems = [
    { Logo: <FaHome size={20} />, name: "Trending" },
    { Logo: <FaShoppingCart size={20} />, name: "Shopping" },
    { Logo: <FaMusic size={20} />, name: "Music" },
    { Logo: <FaFilm size={20} />, name: "Movies" },
    { Logo: <FaTv size={20} />, name: "Live" },
    { Logo: <FaBasketballBall size={20} />, name: "Gaming" },
    { Logo: <FaTv size={20} />, name: "News" },
    { Logo: <FaBasketballBall size={20} />, name: "Sports" },
    { Logo: <FaTv size={20} />, name: "Courses" },
    { Logo: <FaTv size={20} />, name: "Fashion & Beauty" },
    { Logo: <FaPodcast size={20} />, name: "Podcasts" },
  ];

  const moreFromYouTube = [
    { Logo: <FaTv size={20} />, name: "YouTube Premium" },
    { Logo: <FaTv size={20} />, name: "YouTube Studio" },
    { Logo: <FaTv size={20} />, name: "YouTube Music" },
    { Logo: <FaTv size={20} />, name: "YouTube Kids" },
  ];

  const insideSetting = [
    { Logo: <FaTv size={20} />, name: "Settings" },
    { Logo: <FaTv size={20} />, name: "Report History" },
    { Logo: <FaTv size={20} />, name: "Help" },
    { Logo: <FaTv size={20} />, name: "Send Feedback" },
  ];

  return (
    <div className="pt-5">
      {/* Close button */}
      <button
        className="absolute top-7 left-5 text-white text-xl"
        onClick={onClose}
      >
        <FaTimes />
      </button>

      <div className="bg-deep-green absolute top-7 left-30">
        <h2 className="text-white">Logo</h2>
      </div>

      <div className="flex flex-col items-center justify-center h-full">
        {/* Logo Section */}

        {/* Scrollable Container */}
        <div
          className="w-full pt-4 overflow-y-auto pb-10"
          style={{ maxHeight: "calc(100vh)" }}
        >
          <div className="pb-2 border-b-[1px] border-gray-400 flex pt-5 justify-start flex-col">
            {/* Main Menu */}
            {mainMenuItems.map((item, index) => (
              <AsideDiv key={index} Logo={item.Logo} name={item.name} />
            ))}
          </div>

          <div className="flex w-full pt-2 flex-col justify-start">
            <span className="flex p-2 ml-1 cursor-pointer hover:bg-[#e7e7e7] hover:bg-opacity-10">
              You
            </span>
            <ul className="pb-2 ml-2 border-b-[1px] border-gray-400 flex w-full justify-start flex-col">
              {userItems.map((item, index) => (
                <AsideDiv key={index} Logo={item.Logo} name={item.name} />
              ))}
            </ul>
          </div>

          <div className="flex w-full pt-2 flex-col justify-start">
            <span className="flex p-2 ml-1 cursor-pointer hover:bg-[#e7e7e7] hover:bg-opacity-10">
              Explore
            </span>
            <ul className="pb-2 ml-2 border-b-[1px] border-gray-400 flex w-full justify-start flex-col">
              {exploreItems.map((item, index) => (
                <AsideDiv key={index} Logo={item.Logo} name={item.name} />
              ))}
            </ul>
          </div>

          <div className="flex w-full pt-2 flex-col justify-start">
            <span className="flex p-2 ml-1 cursor-pointer hover:bg-[#e7e7e7] hover:bg-opacity-10">
              More From YouTube
            </span>
            <ul className="pb-2 ml-2 border-b-[1px] border-gray-400 flex w-full justify-start flex-col">
              {moreFromYouTube.map((item, index) => (
                <AsideDiv key={index} Logo={item.Logo} name={item.name} />
              ))}
            </ul>
          </div>

          <div className="flex w-full pt-2 flex-col justify-start">
            <span className="flex p-2 ml-1 cursor-pointer hover:bg-[#e7e7e7] hover:bg-opacity-10">
              Settings
            </span>
            <ul className="pb-3 ml-2 border-b-[1px] border-gray-400 flex w-full justify-start flex-col">
              {insideSetting.map((item, index) => (
                <AsideDiv key={index} Logo={item.Logo} name={item.name} />
              ))}
            </ul>
          </div>

          <div className="flex flex-col  text-sm items-center p-3">
            <div className="pb-4 pt-3 ">
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab
                suscipit consequatuisquam voluptatibus rerum iste adipisci, at
                ex vel maiores tempore impedit.
              </p>
            </div>
            <div>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum,
                neque.
              </p>
              <div className=" text-xs text-gray-300 pt-2">
                <p>@2024</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LeftMenu;
