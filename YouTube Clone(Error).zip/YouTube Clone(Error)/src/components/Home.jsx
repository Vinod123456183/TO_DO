import React from "react";
import FilterButton from "./FilterButton";
function Home() {
  const handleFilterClick = () => {
    console.log("Button clicked!");
  };
  return (
    <>
      <div className=" flex flex-col w-full">
        <div className=" w-full flex  justify-between h-10 ">
          <FilterButton text={"All"} onClick={handleFilterClick} />
          <FilterButton text={"Music"} onClick={handleFilterClick} />
          <FilterButton text={"Thriller"} onClick={handleFilterClick} />
          <FilterButton text={"Comedy"} onClick={handleFilterClick} />
          <FilterButton text={"Mixes"} onClick={handleFilterClick} />
          <FilterButton text={"Gb"} onClick={handleFilterClick} />
          <FilterButton text={"Roamce"} onClick={handleFilterClick} />
          <FilterButton text={"Natural "} onClick={handleFilterClick} />
          <FilterButton text={"Focus"} onClick={handleFilterClick} />
          <FilterButton text={"Masala Film"} onClick={handleFilterClick} />
          <FilterButton text={"Dramedy"} onClick={handleFilterClick} />
        </div>

        <div className="bg-fuchsia-200 "></div>
      </div>
    </>
  );
}

export default Home;
