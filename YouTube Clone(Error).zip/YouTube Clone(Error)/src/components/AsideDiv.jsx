import React from "react";
import { FaHome } from "react-icons/fa";

function AsideDiv({ Logo, name, toggleColor }) {
  return (
    <div>
      <li
        onClick={(e) => {
          console.log("BP");
        }}
        className={`text-md flex items-center  gap-7 cursor-pointer hover:bg-[#e7e7e7] hover:bg-opacity-10 p-2 w-full rounded-lg ${
          toggleColor ? "text-red-500" : "text-gray-200"
        }`}
      >
        {Logo}
        <h1>{name}</h1>
      </li>
    </div>
  );
}

export default AsideDiv;
