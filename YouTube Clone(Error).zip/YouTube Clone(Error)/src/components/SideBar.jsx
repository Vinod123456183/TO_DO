import React from "react";

function SideBar() {
  return (
    <div>
      <div>
        <aside className="">
          <ul className="space-y-10 p-4">
            <li>Home</li>
            <li>Shorts</li>
            <li>Subscription</li>
            <li>You</li>
          </ul>
        </aside>
      </div>
    </div>
  );
}

export default SideBar;
