// import Header from "./components/Header";
import { Outlet } from "react-router-dom";
import { AppContext } from "./context/ContextApi";
import Header from "./components/Header";
import SideBar from "./components/SideBar";
function App() {
  return (
    <>
      <AppContext>
        <Header />
        <div className="flex">
          <SideBar />
          <Outlet />
        </div>
      </AppContext>
    </>
  );
}

export default App;
