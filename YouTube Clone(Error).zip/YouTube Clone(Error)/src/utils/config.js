// config.js
export const config = {
  REACT_APP_YOUTUBE_API_KEY:
    "fc7b3a4e8dmsha58357bc9409d2cp13c6b8jsn10848b2132ad",
};
