import axios from "axios";
import { config } from "./config.js"; // Import the config

// Define the base URL for the YouTube API
const BASE_URL = "https://youtube138.p.rapidapi.com";

// Set up the request options for the API call
const options = {
  params: { hl: "en", gl: "US" },
  headers: {
    "X-RapidAPI-Key": config.REACT_APP_YOUTUBE_API_KEY || "YOUR_API_KEY", // Access the key from the config file
    "X-RapidAPI-Host": "youtube138.p.rapidapi.com",
  },
};

// Function to fetch data from the API
export const fetchDataFromApi = async (url) => {
  try {
    // Make the GET request to the YouTube API with the specified URL and options
    const { data } = await axios.get(`${BASE_URL}/${url}`, options);
    return data; // Return the fetched data
  } catch (error) {
    console.error("Error fetching data from YouTube API:", error);
    throw error; // Optionally throw the error to be handled elsewhere
  }
};
