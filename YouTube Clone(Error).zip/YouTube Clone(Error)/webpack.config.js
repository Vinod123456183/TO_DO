const Dotenv = require("dotenv-webpack");

module.exports = {
  // your webpack config here
  plugins: [new Dotenv()],
};
