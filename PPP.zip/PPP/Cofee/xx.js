const buttons = document.getElementsByClassName('cart-button');

const handleClick = (button , event) => {
    const isLoading = button.classList.contains('loading');
    if (!isLoading) {
        button.classList.add('loading');
        const loadingDelay = 3700;
        setTimeout(() => {
            button.classList.remove('loading');
        }, loadingDelay);
    }
    event.preventDefault();
};

Array.from(buttons).forEach(button => {
    button.addEventListener('click', event => {
        handleClick(button, event);
    });
});
