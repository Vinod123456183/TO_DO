const inputBox = document.getElementById('input-box');
const taskList = document.getElementById('task-list');

// Load saved task list data from localStorage on page load
window.addEventListener('DOMContentLoaded', loadTasksFromLocalStorage);

// Function to load tasks from localStorage
function loadTasksFromLocalStorage() {
    const savedTasks = localStorage.getItem("taskList");
    if (savedTasks) {
        taskList.innerHTML = savedTasks; // Restore saved task list HTML
        attachTaskEvents(); // Attach event listeners to restored tasks
    }
}

// Function to add a new task
function addTask() {
    const taskText = inputBox.value.trim();

    if (taskText === '') {
        alert("Please enter a task.");
        return;
    }

    const newTask = createTaskElement(taskText); // Create new task element
    taskList.appendChild(newTask); // Append the new task to the task list

    Save(); // Save task list state

    inputBox.value = ''; // Clear the input box after adding the task
}

// Function to create a task element with delete button
function createTaskElement(taskText) {
    const newTask = document.createElement("li");
    newTask.textContent = taskText;

    const deleteButton = createDeleteButton(); // Create delete button for the task
    newTask.appendChild(deleteButton); // Append delete button to the task item

    newTask.addEventListener('click', toggleTaskStatus); // Toggle task status on click

    return newTask;
}

// Function to create a delete button <span> for a task
function createDeleteButton() {
    const deleteButton = document.createElement("span");
    deleteButton.textContent = '\u00D7'; // Unicode for '×' (times sign)
    deleteButton.className = "close"; // Add a class for styling
    deleteButton.addEventListener('click', deleteTask); // Delete task on delete button click
    return deleteButton;
}

// Function to toggle task status when clicked
function toggleTaskStatus() {
    this.classList.toggle('checked'); // Toggle the 'checked' class on the clicked task
    Save(); // Save task list state after marking task as checked/unchecked
}

// Function to delete a task
function deleteTask(event) {
    const taskItem = this.parentNode; // Get the parent <li> element
    taskItem.remove(); // Remove the task item from the list
    Save(); // Save task list state after removing a task
}

// Function to save current task list state to localStorage
function Save() {
    localStorage.setItem("taskList", taskList.innerHTML); // Save current task list HTML
}

// Function to attach event listeners to all existing task items
function attachTaskEvents() {
    const tasks = taskList.querySelectorAll('li');
    tasks.forEach(task => {
        task.addEventListener('click', toggleTaskStatus); // Toggle task status on click
        const deleteButton = task.querySelector('.close');
        if (deleteButton) {
            deleteButton.addEventListener('click', deleteTask); // Delete task on delete button click
        }
    });
}